package com.healthcheck.codetest.Controller;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.beans.XMLDecoder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Util.println;
import static com.sun.org.apache.xml.internal.serialize.Method.XML;
import static java.awt.SystemColor.info;


@RestController
public class ApiController {

    @GetMapping("/api")
    public String callApi() throws IOException{
        StringBuilder result = new StringBuilder();

        String urlStr = "https://api.archisketch.com/v1/cylinder/product/5EED9DCF76984934";
        URL url = new URL(urlStr);

        HttpURLConnection urlConnection =(HttpURLConnection) url.openConnection();
        urlConnection.setRequestProperty("x-api-key","test");
        urlConnection.setRequestMethod("GET");

        BufferedReader br;
        br = new BufferedReader(new InputStreamReader(urlConnection.getInputStream(),"UTF-8"));

        String returnline;

        while ((returnline = br.readLine()) != null){
            result.append(returnline+"\n\r");

        }
        urlConnection.disconnect();

        String jsonPrintString = null;
        JSONObject jsonObject = XML.toJSONObject(result.toString());
        jsonPrintString = jsonObject.toString();
        for(int i=0; i<jsonObject.size(); i++){
            jsonObject = jsonObject.getJSONObject(i);
            String value = jsonObject.get("name");
            String value1 = jsonObject.get("assetValue");

            println(value);
            println(value1);
        }


        return null;
    }
}

