package com.healthcheck.codetest;

import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

@Service
public class MappingService {
    private String key = "x-api-key";
    private String value = "test";

    private URI buildURI(){
        String endpointURI="https://api.archisketch.com/v1/cylinder/product/5EED9DCF76984934";

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(endpointURI)
                .queryParam("key",key)
                .queryParam("value",value);

        return builder.build().encode().toUri();
    }
}
