package com.healthcheck.codetest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodetestApplicationTests {

	@Test
	void contextLoads() {
	}

}
